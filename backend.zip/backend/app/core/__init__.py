# app/core/__init__.py
# Makes core a package; no runtime logic required.
