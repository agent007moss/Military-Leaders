"""Phase 1 placeholder package for `battle_calendar` module."""

from .api import get_router
