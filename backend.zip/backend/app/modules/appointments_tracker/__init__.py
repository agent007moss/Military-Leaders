"""Phase 1 placeholder package for `appointments_tracker` module."""

from .api import get_router
