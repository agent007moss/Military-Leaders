"""
Phase-1 placeholder schemas for `soldier_profile`.

These are intentionally minimal and do not mirror the real DB models yet.
They exist only so the router can return valid Pydantic responses
without requiring full schema implementation.
"""

from pydantic import BaseModel, Field
from typing import Any, Dict


class ServiceMemberCreate(BaseModel):
    """
    Placeholder POST schema.
    Real fields will be added in Phase 2+.
    """
    payload: Dict[str, Any] = Field(default_factory=dict)


class ServiceMemberRead(BaseModel):
    """
    Placeholder GET/response schema.
    Real representation will be added in Phase 2+.
    """
    id: str
    payload: Dict[str, Any] = Field(default_factory=dict)
