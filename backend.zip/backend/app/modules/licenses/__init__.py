"""Phase 1 placeholder package for `licenses` module."""

from .api import get_router
