"""Phase 1 placeholder package for `medical_profiles` module."""

from .api import get_router
