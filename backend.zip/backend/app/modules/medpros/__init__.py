"""Phase 1 placeholder package for `medpros` module."""

from .api import get_router
