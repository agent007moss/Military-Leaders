"""Phase 1 placeholder package for `weapons` module."""

from .api import get_router
