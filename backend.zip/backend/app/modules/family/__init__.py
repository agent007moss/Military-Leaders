"""Phase 1 placeholder package for `family` module."""

from .api import get_router
