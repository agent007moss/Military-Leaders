# soldier_profile module

Minimal ServiceMember model + basic CRUD.
