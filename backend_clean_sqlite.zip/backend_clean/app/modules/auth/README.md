# auth module

Minimal user model + create/list endpoints.
